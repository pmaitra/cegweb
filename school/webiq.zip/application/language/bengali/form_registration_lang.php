<?php
$lang['registration_form']['first_name'] = '&#2474;&#2509;&#2480;&#2469;&#2478; &#2472;&#2494;&#2478;';
$lang['registration_form']['middle_name'] = '&#x09AE;&#x09A7;&#x09CD;&#x09AF;&#x09AE; &#x09A8;&#x09BE;&#x09AE;';
$lang['registration_form']['last_name'] = '&#x09AA;&#x09A6;&#x09AC;&#x09BF;';
$lang['registration_form']['date_of_birth'] = '&#x099C;&#x09A8;&#x09CD;&#x09AE; &#x09A4;&#x09BE;&#x09B0;&#x09BF;&#x0996;';
$lang['registration_form']['sex'] = '&#x09B2;&#x09BF;&#x0999;&#x09CD;&#x0997;';
$lang['registration_form']['marital_status'] = '&#x09AC;&#x09C8;&#x09AC;&#x09BE;&#x09B9;&#x09BF;&#x0995; &#x0985;&#x09AC;&#x09B8;&#x09CD;&#x09A5;&#x09BE;';

$lang['registration_form']['contact_number'] = '&#x09AF;&#x09CB;&#x0997;&#x09BE;&#x09AF;&#x09CB;&#x0997;&#x09C7;&#x09B0; &#x09A8;&#x09AE;&#x09CD;&#x09AC;&#x09B0;';
$lang['registration_form']['email'] = '&#x0987;-&#x09AE;&#x09C7;&#x0987;&#x09B2;';
$lang['registration_form']['address_1'] = '&#x09A0;&#x09BF;&#x0995;&#x09BE;&#x09A8;&#x09BE;';
$lang['registration_form']['address_2'] = '&#x09A0;&#x09BF;&#x0995;&#x09BE;&#x09A8;&#x09BE;';
$lang['registration_form']['state'] = '&#x09B0;&#x09BE;&#x099C;&#x09CD;&#x09AF;';
$lang['registration_form']['city'] = '&#x09B6;&#x09B9;&#x09B0;';
$lang['registration_form']['zip_code'] = '&#x09AA;&#x09BF;&#x09A8;&#x0995;&#x09CB;&#x09A1;';
$lang['registration_form']['country'] = '&#x09A6;&#x09C7;&#x09B6;';
$lang['registration_form']['profile_picture'] = '&#x099B;&#x09AC;&#x09BF;';
/* 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

