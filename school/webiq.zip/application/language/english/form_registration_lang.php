<?php
$lang['registration_form']['first_name'] = 'First Name';
$lang['registration_form']['middle_name'] = 'Middle Name';
$lang['registration_form']['last_name'] = 'Last Name';
$lang['registration_form']['date_of_birth'] = 'Date of Birth';
$lang['registration_form']['sex'] = 'Sex';
$lang['registration_form']['marital_status'] = 'Marital Status';

$lang['registration_form']['contact_number'] = 'Contact Number';
$lang['registration_form']['email'] = 'E-Mail';
$lang['registration_form']['address_1'] = 'Street Address';
$lang['registration_form']['address_2'] = 'Marital Status';
$lang['registration_form']['state'] = 'State';
$lang['registration_form']['city'] = 'City';
$lang['registration_form']['zip_code'] = 'Zip code';
$lang['registration_form']['country'] = 'Country';
$lang['registration_form']['profile_picture'] = 'Profile picture';
 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

