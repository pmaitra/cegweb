
    $(document).on('change', '#goToUrl', function(){
        location.href = $(this).val();
    });
